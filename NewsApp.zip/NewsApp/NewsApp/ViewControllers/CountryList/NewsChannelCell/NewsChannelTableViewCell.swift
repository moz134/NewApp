//
//  NewsChannelTableViewCell.swift
//  NewsApp
//
//  Created by md mozammil on 22/05/22.
//

import UIKit

class NewsChannelTableViewCell: UITableViewCell {

    @IBOutlet var channelName: UILabel?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

}
